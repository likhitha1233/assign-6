// Assignment 6, Question 2: Deadlock Detection using a Resource Allocation
// Graph / wait-for graph. Pure user-space simulation (no new syscalls
// needed): builds a wait-for graph from a hardcoded allocation matrix
// (which process holds which resource) and request matrix (which process
// is waiting for which resource), then runs a DFS-based cycle detector
// over it.
//
// Model: NPROC processes, NRES resource types, each resource type
// represented as a single instance for the purposes of building the
// wait-for graph (the standard simplification used for cycle-based
// deadlock detection): alloc[p][r] == 1 means process p currently holds
// resource r; request[p][r] == 1 means process p is currently blocked
// waiting for resource r.
//
// An edge P_i -> P_j is added to the wait-for graph whenever P_i is
// waiting for some resource r that P_j currently holds. A cycle in this
// graph is both a necessary and (for single-instance resources) a
// sufficient condition for deadlock.

#include "kernel/types.h"
#include "user/user.h"

#define NPROC 5
#define NRES  4

static int alloc[NPROC][NRES];
static int request[NPROC][NRES];
static int waitfor[NPROC][NPROC];

static void
build_waitfor_graph(void)
{
  int i, j, r;

  for (i = 0; i < NPROC; i++)
    for (j = 0; j < NPROC; j++)
      waitfor[i][j] = 0;

  for (i = 0; i < NPROC; i++) {
    for (r = 0; r < NRES; r++) {
      if (!request[i][r])
        continue;
      for (j = 0; j < NPROC; j++) {
        if (j != i && alloc[j][r]) {
          waitfor[i][j] = 1;
          printf("Edge: P%d -> P%d  (P%d waits for R%d, held by P%d)\n", i,
                 j, i, r, j);
        }
      }
    }
  }
}

// DFS-based cycle detection. `stackpath` records the current DFS path;
// `onstack` marks nodes currently on that path (the standard way to find
// a *back edge*, which is exactly a cycle, in a directed graph).
static int visited[NPROC];
static int onstack[NPROC];
static int stackpath[NPROC];
static int stacklen;

static int
print_cycle_from(int start_node)
{
  int i, idx = -1;

  for (i = 0; i < stacklen; i++) {
    if (stackpath[i] == start_node) {
      idx = i;
      break;
    }
  }
  printf("Deadlock cycle: ");
  for (i = idx; i < stacklen; i++)
    printf("P%d -> ", stackpath[i]);
  printf("P%d\n", start_node);
  return 1;
}

static int
dfs(int u)
{
  int v;

  visited[u] = 1;
  onstack[u] = 1;
  stackpath[stacklen++] = u;

  for (v = 0; v < NPROC; v++) {
    if (!waitfor[u][v])
      continue;
    if (onstack[v]) {
      // Found a back edge u -> v where v is still on the current DFS
      // path: that is precisely a cycle.
      print_cycle_from(v);
      return 1;
    }
    if (!visited[v]) {
      if (dfs(v))
        return 1;
    }
  }

  onstack[u] = 0;
  stacklen--;
  return 0;
}

static int
detect_deadlock(void)
{
  int i;
  for (i = 0; i < NPROC; i++) {
    visited[i] = 0;
    onstack[i] = 0;
  }
  stacklen = 0;
  for (i = 0; i < NPROC; i++) {
    if (!visited[i]) {
      if (dfs(i))
        return 1;
    }
  }
  return 0;
}

static void
clear_matrices(void)
{
  int i, j;
  for (i = 0; i < NPROC; i++)
    for (j = 0; j < NRES; j++) {
      alloc[i][j] = 0;
      request[i][j] = 0;
    }
}

static void
run_scenario(const char *title)
{
  printf("=== %s ===\n", title);
  build_waitfor_graph();
  if (detect_deadlock())
    printf("Result: DEADLOCK DETECTED.\n\n");
  else
    printf("Result: no deadlock (wait-for graph is acyclic).\n\n");
}

int
main(void)
{
  // ---- Scenario 1: no deadlock (acyclic wait-for graph) ----
  // P0 holds R0, P1 holds R1, P2 holds R2, P3 holds R3, P4 holds nothing.
  // P0 waits for R1 (-> P1); P1 waits for R2 (-> P2); P4 waits for R0
  // (-> P0). This forms two separate chains (P4->P0->P1->P2), no cycle.
  clear_matrices();
  alloc[0][0] = 1;
  alloc[1][1] = 1;
  alloc[2][2] = 1;
  alloc[3][3] = 1;
  request[0][1] = 1; // P0 waits for R1
  request[1][2] = 1; // P1 waits for R2
  request[4][0] = 1; // P4 waits for R0
  run_scenario("Scenario 1: acyclic wait-for graph");

  // ---- Scenario 2: deadlock, 3-process circular wait ----
  // P0 holds R0 & waits for R1 (held by P1)
  // P1 holds R1 & waits for R2 (held by P2)
  // P2 holds R2 & waits for R0 (held by P0)   => cycle P0->P1->P2->P0
  // P3 holds R3, not waiting on anything (uninvolved bystander)
  // P4 waits for R3 (held by P3), but P3 isn't blocked, so P4 is not
  // part of any cycle even though it does appear in the graph.
  clear_matrices();
  alloc[0][0] = 1;
  alloc[1][1] = 1;
  alloc[2][2] = 1;
  alloc[3][3] = 1;
  request[0][1] = 1; // P0 waits for R1 (held by P1)
  request[1][2] = 1; // P1 waits for R2 (held by P2)
  request[2][0] = 1; // P2 waits for R0 (held by P0)  -- closes the cycle
  request[4][3] = 1; // P4 waits for R3 (held by P3), independent edge
  run_scenario("Scenario 2: 3-process circular wait (deadlock)");

  exit(0);
}
