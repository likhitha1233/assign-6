// Assignment 6, Question 1: Banker's Algorithm Simulation.
//
// A pure user-space simulation (no new syscalls needed) modeling n
// processes and m resource types with the standard Banker's Algorithm data
// structures, using the classic textbook scenario (Silberschatz et al.,
// "Operating System Concepts", the 5-process / 3-resource-type example) so
// the expected safe sequence and grant/deny outcomes are independently
// verifiable against the textbook.
//
// Usage:
//   bankers                      -> run the two built-in demo scenarios
//                                    (one granted request, one denied request)
//   bankers <pid> <r0> <r1> <r2> -> also try one extra request read from argv,
//                                    on top of the original hardcoded state

#include "kernel/types.h"
#include "user/user.h"

#define NPROC 5
#define NRES  3

static int Allocation[NPROC][NRES];
static int Max[NPROC][NRES];
static int Available[NRES];
static int Need[NPROC][NRES];

// A saved copy of the original hardcoded scenario, used to reset state
// between independent test scenarios.
static int Allocation0[NPROC][NRES];
static int Max0[NPROC][NRES];
static int Available0[NRES];

static void
init_scenario(void)
{
  // Classic textbook example: 5 processes, resources A, B, C with
  // 10, 5, 7 total instances respectively.
  int alloc[NPROC][NRES] = {
      {0, 1, 0}, // P0
      {2, 0, 0}, // P1
      {3, 0, 2}, // P2
      {2, 1, 1}, // P3
      {0, 0, 2}, // P4
  };
  int max[NPROC][NRES] = {
      {7, 5, 3}, // P0
      {3, 2, 2}, // P1
      {9, 0, 2}, // P2
      {2, 2, 2}, // P3
      {4, 3, 3}, // P4
  };
  int avail[NRES] = {3, 3, 2};
  int i, j;

  for (i = 0; i < NPROC; i++) {
    for (j = 0; j < NRES; j++) {
      Allocation[i][j] = Allocation0[i][j] = alloc[i][j];
      Max[i][j] = Max0[i][j] = max[i][j];
    }
  }
  for (j = 0; j < NRES; j++)
    Available[j] = Available0[j] = avail[j];
}

static void
reset_scenario(void)
{
  int i, j;
  for (i = 0; i < NPROC; i++)
    for (j = 0; j < NRES; j++)
      Allocation[i][j] = Allocation0[i][j];
  for (j = 0; j < NRES; j++)
    Available[j] = Available0[j];
}

static void
compute_need(void)
{
  int i, j;
  for (i = 0; i < NPROC; i++)
    for (j = 0; j < NRES; j++)
      Need[i][j] = Max[i][j] - Allocation[i][j];
}

static void
print_row(const char *label, int *row)
{
  int j;
  printf("%s", label);
  for (j = 0; j < NRES; j++)
    printf("%d ", row[j]);
  printf("\n");
}

static void
print_state(void)
{
  int i;
  char name[8];

  printf("        Allocation   Max          Need\n");
  for (i = 0; i < NPROC; i++) {
    name[0] = 'P';
    name[1] = '0' + i;
    name[2] = ':';
    name[3] = ' ';
    name[4] = 0;
    printf("%s", name);
    printf("%d %d %d      ", Allocation[i][0], Allocation[i][1],
           Allocation[i][2]);
    printf("%d %d %d      ", Max[i][0], Max[i][1], Max[i][2]);
    printf("%d %d %d\n", Need[i][0], Need[i][1], Need[i][2]);
  }
  print_row("Available: ", Available);
}

// Safety algorithm. On success returns 1 and fills safeSeq[0..NPROC-1]
// with a valid safe execution order; on failure returns 0.
static int
is_safe(int *safeSeq)
{
  int work[NRES];
  int finish[NPROC];
  int i, j, count, found;

  for (j = 0; j < NRES; j++)
    work[j] = Available[j];
  for (i = 0; i < NPROC; i++)
    finish[i] = 0;

  count = 0;
  while (count < NPROC) {
    found = 0;
    for (i = 0; i < NPROC; i++) {
      if (finish[i])
        continue;
      int ok = 1;
      for (j = 0; j < NRES; j++) {
        if (Need[i][j] > work[j]) {
          ok = 0;
          break;
        }
      }
      if (ok) {
        for (j = 0; j < NRES; j++)
          work[j] += Allocation[i][j];
        finish[i] = 1;
        safeSeq[count++] = i;
        found = 1;
      }
    }
    if (!found)
      break; // no process could be scheduled -> unsafe
  }
  return count == NPROC;
}

static void
print_seq(int *seq)
{
  int i;
  printf("Safe sequence: <");
  for (i = 0; i < NPROC; i++) {
    printf("P%d", seq[i]);
    if (i != NPROC - 1)
      printf(", ");
  }
  printf(">\n");
}

// Resource-Request Algorithm (Habermann's algorithm). Returns:
//   0  -> granted, new state committed
//  -1  -> denied, request exceeds Need[pid]
//  -2  -> denied, request exceeds Available
//  -3  -> denied, would lead to an unsafe state (rolled back)
static int
request_resources(int pid, int *request)
{
  int j, safeSeq[NPROC];

  for (j = 0; j < NRES; j++) {
    if (request[j] > Need[pid][j]) {
      printf("Request denied: exceeds Need[P%d]\n", pid);
      return -1;
    }
  }
  for (j = 0; j < NRES; j++) {
    if (request[j] > Available[j]) {
      printf("Request denied: exceeds Available\n");
      return -2;
    }
  }

  // Tentatively grant.
  for (j = 0; j < NRES; j++) {
    Available[j] -= request[j];
    Allocation[pid][j] += request[j];
    Need[pid][j] -= request[j];
  }

  if (is_safe(safeSeq)) {
    printf("Request GRANTED for P%d -- resulting state is safe.\n", pid);
    print_seq(safeSeq);
    return 0;
  }

  // Roll back.
  for (j = 0; j < NRES; j++) {
    Available[j] += request[j];
    Allocation[pid][j] -= request[j];
    Need[pid][j] += request[j];
  }
  printf("Request denied - would lead to unsafe state\n");
  return -3;
}

int
main(int argc, char *argv[])
{
  int safeSeq[NPROC];

  init_scenario();
  compute_need();

  printf("=== Initial system state ===\n");
  print_state();
  if (is_safe(safeSeq)) {
    printf("System is in a SAFE state.\n");
    print_seq(safeSeq);
  } else {
    printf("System is in an UNSAFE state!\n");
  }

  printf("\n=== Scenario A: P1 requests (1,0,2) (expected: GRANTED) ===\n");
  {
    int req[NRES] = {1, 0, 2};
    request_resources(1, req);
  }
  print_state();

  printf("\n=== Scenario B: continuing from Scenario A's state, P0 "
         "requests (0,2,0) (expected: DENIED) ===\n");
  {
    int req[NRES] = {0, 2, 0};
    request_resources(0, req);
  }
  print_state();

  if (argc == 1 + 1 + NRES) {
    int pid = atoi(argv[1]);
    int req[NRES];
    int j;
    for (j = 0; j < NRES; j++)
      req[j] = atoi(argv[2 + j]);

    printf("\n=== Scenario C (from argv): reset, then P%d requests "
           "(%d,%d,%d) ===\n",
           pid, req[0], req[1], req[2]);
    reset_scenario();
    compute_need();
    if (pid < 0 || pid >= NPROC) {
      printf("bankers: invalid process id %d\n", pid);
    } else {
      request_resources(pid, req);
      print_state();
    }
  }

  exit(0);
}
