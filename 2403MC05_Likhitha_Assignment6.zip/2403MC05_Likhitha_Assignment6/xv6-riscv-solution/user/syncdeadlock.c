// Assignment 6, Question 4: Combined Synchronization & Deadlock Avoidance.
//
// 5 processes, each needing 2 out of 3 shared resource *types* -- a
// printer pool (2 instances), a scanner pool (1 instance), and a disk pool
// (2 instances). Each pool is a counting semaphore (reusing the same
// sem_alloc/sem_wait/sem_signal kernel syscalls built for Assignment 5 and
// reused again in Question 3), sized to the pool's instance count.
//
// Deadlock-avoidance strategy used: RESOURCE ORDERING, reused directly
// from Question 3. The three resource types are given a fixed global
// order: Printer(0) < Scanner(1) < Disk(2). Every process, no matter which
// two resource types it personally needs, always requests them in
// increasing order (e.g. a process that needs "disk and printer" still
// requests the printer first, then the disk). Exactly as in Q3, a single
// total order that every process obeys makes a circular wait impossible:
// whichever process reaches the lower resource in the ordering first is
// guaranteed to never be blocked holding a higher resource while a lower
// one it needs is stuck behind another process -- so the classic
// "each holds one, waits on the other" cycle cannot form, regardless of
// how many processes or resource types are involved. This is the same
// argument as in Q3, generalized from 2 resources to 3.
//
// A shared page (via shm_get(), also reused from Assignment 5) holds a
// live in-use counter per resource type, updated under its own mutex
// semaphore, so the printed counts can be directly checked against the
// pool capacities to confirm no pool is ever over-subscribed.

#include "kernel/types.h"
#include "user/user.h"

#define NPROC   5
#define NTYPES  3
#define CYCLES  4

#define PRINTER 0
#define SCANNER 1
#define DISK    2

static const char *names[NTYPES] = {"Printer", "Scanner", "Disk"};
static const int capacity[NTYPES] = {2, 1, 2};

struct counters {
  int inuse[NTYPES];
};

// Each process needs this pair of resource types (already listed in
// increasing global order -- Printer(0) < Scanner(1) < Disk(2) -- but we
// still sort defensively in acquire_pair()/release_pair() below in case
// this table is ever edited to list a pair out of order).
static const int need[NPROC][2] = {
    {PRINTER, SCANNER}, // P0
    {SCANNER, DISK},    // P1
    {PRINTER, DISK},    // P2
    {PRINTER, SCANNER}, // P3
    {SCANNER, DISK},    // P4
};

static void
work_delay(void)
{
  volatile int i;
  for (i = 0; i < 500000; i++)
    ;
}

static void
change_count(struct counters *ctr, int mutex, int type, int delta)
{
  sem_wait(mutex);
  ctr->inuse[type] += delta;
  sem_signal(mutex);
}

int
main(void)
{
  struct counters *ctr;
  int pool[NTYPES]; // semaphore ids for the 3 resource pools
  int mutex;        // protects ctr->inuse[]
  int t;
  int i, pid;

  ctr = (struct counters *)shm_get();
  if (ctr == 0) {
    printf("syncdeadlock: shm_get failed\n");
    exit(1);
  }
  // shm_get() zero-fills the page, so all in-use counts already start at 0.

  for (t = 0; t < NTYPES; t++) {
    pool[t] = sem_alloc(capacity[t]);
    if (pool[t] < 0) {
      printf("syncdeadlock: sem_alloc failed\n");
      exit(1);
    }
  }
  mutex = sem_alloc(1);
  if (mutex < 0) {
    printf("syncdeadlock: sem_alloc failed\n");
    exit(1);
  }

  printf("syncdeadlock: %d processes, %d cycles each, pools = "
         "Printer:%d Scanner:%d Disk:%d, strategy = resource ordering "
         "(Printer < Scanner < Disk)\n",
         NPROC, CYCLES, capacity[PRINTER], capacity[SCANNER],
         capacity[DISK]);

  for (i = 0; i < NPROC; i++) {
    pid = fork();
    if (pid < 0) {
      printf("syncdeadlock: fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      int a = need[i][0];
      int b = need[i][1];
      int c;

      if (a > b) { // defensive sort into increasing global order
        c = a;
        a = b;
        b = c;
      }

      for (c = 0; c < CYCLES; c++) {
        printf("P%d: requesting %s\n", i, names[a]);
        sem_wait(pool[a]);
        change_count(ctr, mutex, a, +1);
        printf("P%d: granted %s (now %d/%d in use)\n", i, names[a],
               ctr->inuse[a], capacity[a]);

        printf("P%d: requesting %s\n", i, names[b]);
        sem_wait(pool[b]);
        change_count(ctr, mutex, b, +1);
        printf("P%d: granted %s (now %d/%d in use)\n", i, names[b],
               ctr->inuse[b], capacity[b]);

        printf("P%d: working with %s + %s (cycle %d)\n", i, names[a],
               names[b], c + 1);
        work_delay();

        change_count(ctr, mutex, b, -1);
        sem_signal(pool[b]);
        change_count(ctr, mutex, a, -1);
        sem_signal(pool[a]);
        printf("P%d: released %s and %s (cycle %d done)\n", i, names[b],
               names[a], c + 1);
      }
      printf("P%d: completed all %d cycles\n", i, CYCLES);
      exit(0);
    }
  }

  for (i = 0; i < NPROC; i++)
    wait(0);

  for (t = 0; t < NTYPES; t++)
    sem_destroy(pool[t]);
  sem_destroy(mutex);

  printf("syncdeadlock: all %d processes completed %d cycles each -- no "
         "deadlock occurred, no pool ever exceeded its capacity\n",
         NPROC, CYCLES);

  exit(0);
}
