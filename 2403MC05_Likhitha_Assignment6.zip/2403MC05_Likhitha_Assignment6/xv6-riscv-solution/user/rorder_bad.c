// Assignment 6, Question 3 (buggy version): demonstrates a real circular-
// wait deadlock between two actual xv6 processes.
//
// Lock1 and Lock2 are two real kernel semaphores (binary, via the sem_*
// syscalls added for Assignment 5's kernel semaphore facility -- reused
// here exactly as the assignment permits: "a custom semaphore syscall
// from a previous assignment").
//
// Process A acquires Lock1, then (after a deliberate busy-wait delay, to
// make the race reliable) tries to acquire Lock2.
// Process B acquires Lock2, then (after the same delay) tries to acquire
// Lock1.
//
// Once both processes have completed their first acquisition, each is
// permanently blocked waiting for a lock the other one holds -- a classic
// circular wait -- so this program is EXPECTED TO HANG. It must be run
// with an external timeout (see output_logs/rorder_bad.log and the
// top-level README for exactly how this was captured); there is no
// internal recovery from this deadlock by design, since the whole point
// is to demonstrate the problem before Question 3's fix.

#include "kernel/types.h"
#include "user/user.h"

// A plain CPU busy-wait, as requested by the assignment text, used to
// force both processes to be holding their *first* lock and contending
// for their *second* lock at (very close to) the same time, so the
// deadlock reproduces reliably on every run.
static void
delay(void)
{
  volatile int i;
  for (i = 0; i < 3000000; i++)
    ;
}

int
main(void)
{
  int lock1, lock2;
  int pid;

  lock1 = sem_alloc(1);
  lock2 = sem_alloc(1);
  if (lock1 < 0 || lock2 < 0) {
    printf("rorder_bad: sem_alloc failed\n");
    exit(1);
  }

  printf("rorder_bad: demonstrating the deadlock (inconsistent "
         "lock ordering)\n");

  pid = fork();
  if (pid < 0) {
    printf("rorder_bad: fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // ---- Process B: acquires Lock2 first, then Lock1 ----
    printf("Process B: trying Lock2\n");
    sem_wait(lock2);
    printf("Process B: acquired Lock2\n");

    delay();

    printf("Process B: trying Lock1\n");
    sem_wait(lock1); // BLOCKS FOREVER: A is holding Lock1, waiting on Lock2
    printf("Process B: acquired Lock1\n");

    sem_signal(lock1);
    sem_signal(lock2);
    printf("Process B: released both locks, done\n");
    exit(0);
  } else {
    // ---- Process A: acquires Lock1 first, then Lock2 ----
    printf("Process A: trying Lock1\n");
    sem_wait(lock1);
    printf("Process A: acquired Lock1\n");

    delay();

    printf("Process A: trying Lock2\n");
    sem_wait(lock2); // BLOCKS FOREVER: B is holding Lock2, waiting on Lock1
    printf("Process A: acquired Lock2\n");

    sem_signal(lock2);
    sem_signal(lock1);
    printf("Process A: released both locks, done\n");

    wait(0);
    printf("rorder_bad: both processes finished (should NEVER "
           "print -- if you see this, the deadlock did not reproduce)\n");
  }

  exit(0);
}
