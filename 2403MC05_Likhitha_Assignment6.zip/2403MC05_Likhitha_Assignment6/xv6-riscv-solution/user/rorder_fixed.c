// Assignment 6, Question 3 (fixed version): the same workload as
// resourceorder_bad.c, but with the deadlock prevented by resource
// ordering (hierarchical allocation) -- every process acquires the two
// locks in the same global order, Lock1 before Lock2, regardless of which
// lock it is "logically" more interested in first.
//
// Why this eliminates the deadlock: one of the four Coffman conditions
// required for deadlock is *circular wait* -- a cycle of processes each
// holding a resource the next one in the cycle is waiting for. With a
// single, total, global ordering imposed on all resources, and every
// process required to request resources in strictly increasing order,
// no such cycle can ever form: whichever process reaches the *lower*-
// ordered resource in the cycle first is guaranteed to already hold every
// resource earlier in the order that it needs, so it can never be stuck
// waiting on a resource "behind" it in the order while a lower-ordered
// resource it still needs is held by a process ahead of it. Concretely
// here: since *both* processes always take Lock1 before ever attempting
// Lock2, whichever process gets Lock1 first is guaranteed to get Lock2
// as well (the other one simply blocks on Lock1 until the first process
// is completely done) -- there is no possible interleaving in which each
// process ends up holding one lock while waiting on the other.

#include "kernel/types.h"
#include "user/user.h"

static void
delay(void)
{
  volatile int i;
  for (i = 0; i < 3000000; i++)
    ;
}

int
main(void)
{
  int lock1, lock2;
  int pid;

  lock1 = sem_alloc(1);
  lock2 = sem_alloc(1);
  if (lock1 < 0 || lock2 < 0) {
    printf("rorder_fixed: sem_alloc failed\n");
    exit(1);
  }

  printf("rorder_fixed: demonstrating the fix (consistent global "
         "lock ordering: Lock1 before Lock2, always)\n");

  pid = fork();
  if (pid < 0) {
    printf("rorder_fixed: fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // ---- Process B: now ALSO takes Lock1 before Lock2 ----
    printf("Process B: trying Lock1\n");
    sem_wait(lock1);
    printf("Process B: acquired Lock1\n");

    delay();

    printf("Process B: trying Lock2\n");
    sem_wait(lock2);
    printf("Process B: acquired Lock2\n");

    sem_signal(lock2);
    sem_signal(lock1);
    printf("Process B: released both locks, done\n");
    exit(0);
  } else {
    // ---- Process A: takes Lock1 before Lock2 (same order as B) ----
    printf("Process A: trying Lock1\n");
    sem_wait(lock1);
    printf("Process A: acquired Lock1\n");

    delay();

    printf("Process A: trying Lock2\n");
    sem_wait(lock2);
    printf("Process A: acquired Lock2\n");

    sem_signal(lock2);
    sem_signal(lock1);
    printf("Process A: released both locks, done\n");

    wait(0);
    printf("rorder_fixed: both processes finished successfully -- "
           "no deadlock\n");
  }

  exit(0);
}
