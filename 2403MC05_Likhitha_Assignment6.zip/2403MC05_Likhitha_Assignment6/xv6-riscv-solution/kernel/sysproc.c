#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0; // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if (t == SBRK_EAGER || n < 0) {
    if (growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
      return -1;
    if (addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if (n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    release(&tickslock);
    sleep();
    acquire(&tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// Assignment 5, Q1: hand back the (single) shared page for this process,
// allocating and mapping it on first use. A second call from the same
// process just returns the same address again. Children created by
// fork() *after* this call automatically get the same physical page
// mapped at the same address (see kfork() in proc.c) -- that is how the
// page ends up genuinely shared between a parent and its children.
uint64
sys_shm_get(void)
{
  struct proc *p = myproc();
  void *pa;

  if (p->shm_pa == 0) {
    if ((pa = shm_alloc()) == 0)
      return 0;
    if (mappages(p->pagetable, SHMVA, PGSIZE, (uint64)pa,
                 PTE_R | PTE_W | PTE_U) < 0) {
      shm_decref(pa);
      return 0;
    }
    p->shm_pa = pa;
    p->shm_va = SHMVA;
  }
  return p->shm_va;
}

// Assignment 5, Q2-Q4: thin syscall wrappers around the kernel semaphore
// facility in sem.c.
uint64
sys_sem_alloc(void)
{
  int value;

  argint(0, &value);
  return (uint64)sem_alloc(value);
}

uint64
sys_sem_wait(void)
{
  int id;

  argint(0, &id);
  return (uint64)sem_wait(id);
}

uint64
sys_sem_signal(void)
{
  int id;

  argint(0, &id);
  return (uint64)sem_signal(id);
}

uint64
sys_sem_destroy(void)
{
  int id;

  argint(0, &id);
  return (uint64)sem_destroy(id);
}
