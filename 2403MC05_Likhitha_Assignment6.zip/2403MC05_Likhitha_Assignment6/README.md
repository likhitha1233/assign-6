# Assignment 6 -- Deadlock Avoidance / Detection / Prevention in xv6

Reference solution for all four questions, built as a real xv6-riscv
source tree (based on [mit-pdos/xv6-riscv](https://github.com/mit-pdos/xv6-riscv)).

Questions 3 and 4 reuse the kernel semaphore facility (`sem_alloc`/
`sem_wait`/`sem_signal`/`sem_destroy`) and the shared-memory syscall
(`shm_get`) that were added to the kernel for the previous assignment
(Process Synchronization using xv6), exactly as this assignment's brief
explicitly permits ("a custom semaphore syscall from a previous
assignment"). No further kernel changes were needed for Questions 1 and 2,
which are pure user-space simulations.

```
2403MC05_Likhitha_Assignment6/
├── README.md                    <- this file
├── CHANGES.diff                 <- diff of Assignment 6's own additions only
│                                    (new user/ programs + Makefile entries;
│                                    does NOT include the kernel semaphore/
│                                    shared-memory work, which was already
│                                    built and verified for the previous
│                                    assignment and is simply reused here)
├── output_logs/                 <- real terminal transcripts from QEMU
│   ├── bankers.log
│   ├── deadlockdetect.log
│   ├── rorder_bad.log           <- the deadlocking run (manually timed out)
│   ├── rorder_fixed.log
│   └── syncdeadlock.log
└── xv6-riscv-solution/          <- full, buildable xv6 source tree
    ├── kernel/                  <- unchanged from the previous assignment
    │                               (still has shm_get()/sem_* built in)
    ├── user/                   <- bankers.c, deadlockdetect.c, rorder_bad.c,
    │                              rorder_fixed.c, syncdeadlock.c
    ├── Makefile
    └── ...                      <- everything else, unmodified xv6-riscv
```

## How to build and run

```
cd xv6-riscv-solution
make qemu
```

Requires a RISC-V cross toolchain and QEMU (e.g. on Ubuntu:
`sudo apt-get install gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu qemu-system-misc`).

At the `$` shell prompt:

```
$ bankers                 # Q1
$ deadlockdetect          # Q2
$ rorder_bad              # Q3, deliberately deadlocks -- see note below
$ rorder_fixed            # Q3, fixed version
$ syncdeadlock            # Q4
```

**Note on `rorder_bad`**: this program is *designed* to deadlock and will
hang forever once both processes have taken their first lock -- that is
the whole point of the demonstration (see Question 3 below). Run it with
an external timeout, e.g. `timeout 20 make qemu` or, inside QEMU, just let
it sit for ~15 seconds with no new output and then power off the VM
(Ctrl-a x) or note the hang manually. `output_logs/rorder_bad.log` was
captured exactly this way and includes a note at the end recording how the
hang was confirmed.

**Note on interleaved console output**: with several processes writing to
the console at once (readwrite in the previous assignment, and here
`syncdeadlock`'s five processes), xv6's console is not atomic per line, so
you may occasionally see two processes' output interleaved character by
character on screen (visible in `output_logs/syncdeadlock.log`). This is a
cosmetic property of the shared UART console, not a bug in the actual
synchronization logic -- the semaphores correctly protect every shared
resource regardless of what the console rendering looks like.

---

## Question 1: Banker's Algorithm (`user/bankers.c`)

Pure user-space simulation (no kernel changes) using the classic 5-process,
3-resource-type textbook scenario (Silberschatz et al., *Operating System
Concepts*), so the expected results are independently checkable:

* `Allocation[5][3]`, `Max[5][3]`, `Available[3]`, and `Need[5][3]` (computed
  at runtime as `Max - Allocation`) are hardcoded with the standard example
  values (resources A/B/C totalling 10/5/7 instances).
* **Safety algorithm**: standard `Work`/`Finish` simulation; returns whether
  the state is safe and, if so, a valid safe sequence.
* **Resource-Request algorithm** (Habermann's algorithm): validates the
  request against `Need[i]` and `Available`, tentatively grants it, re-runs
  the safety algorithm, and either commits (prints the new safe sequence)
  or rolls back and prints `Request denied - would lead to unsafe state`.
* **Two chained test scenarios**, exactly matching the textbook's own
  worked example:
  - *Scenario A* (granted): P1 requests `(1,0,2)` -> granted, resulting
    state is safe (`<P1, P3, P4, P0, P2>` or equivalent).
  - *Scenario B* (denied): continuing from Scenario A's state (this
    matters -- it is *not* re-evaluated from scratch), P0 requests
    `(0,2,0)` -> denied, because granting it would leave no process able
    to finish (every remaining process's `Need` would exceed the reduced
    `Available`).
* A third, optional scenario can be supplied via `argv` (`bankers <pid>
  <r0> <r1> <r2>`), evaluated fresh against the original hardcoded state,
  satisfying the "hardcoded or via argv" requirement.

`output_logs/bankers.log` shows the initial safe state, the granted
request, and the denied request, with the full Allocation/Max/Need/
Available tables printed at each step for inspection.

## Question 2: Deadlock Detection via RAG / Wait-For Graph (`user/deadlockdetect.c`)

Also pure user-space. Processes and resources are modeled with an
`alloc[NPROC][NRES]` matrix (who holds what) and a `request[NPROC][NRES]`
matrix (who is waiting for what), using the standard single-instance-per-
type simplification for building a wait-for graph: an edge `Pi -> Pj` is
added whenever `Pi` is waiting on a resource that `Pj` currently holds.

* A DFS-based cycle detector (with an explicit recursion-stack array,
  not just a visited set) walks the resulting graph; when it finds a back
  edge into a node still on the current DFS path, that is a cycle, and the
  exact path is printed (e.g. `P0 -> P1 -> P2 -> P0`).
* **Scenario 1** (no deadlock): a 5-process, 4-resource setup whose
  wait-for graph is a simple DAG (`P4 -> P0 -> P1 -> P2`).
* **Scenario 2** (deadlock): a genuine 3-process circular wait
  (`P0 -> P1 -> P2 -> P0`), plus two additional, uninvolved processes
  (one holding a resource and not waiting on anything, one waiting on
  it) to show the detector correctly isolates only the processes that
  are actually part of the cycle -- demonstrating this isn't limited to
  simple 2-process deadlocks.

`output_logs/deadlockdetect.log` shows the constructed edges for both
scenarios and the correct verdict (`no deadlock` / `DEADLOCK DETECTED`
with the exact cycle) for each.

## Question 3: Deadlock Prevention via Resource Ordering (`user/rorder_bad.c`, `user/rorder_fixed.c`)

Two real xv6 programs (not simulations), each forking two actual
processes and using two real kernel semaphores, `Lock1` and `Lock2`
(binary, via `sem_alloc(1)`), as the two shared resources.

* **`rorder_bad`** (the problem): Process A acquires `Lock1` then, after a
  busy-wait delay, tries `Lock2`. Process B acquires `Lock2` then, after
  the same delay, tries `Lock1`. The delay makes it reliable that both
  processes are holding their first lock and contending for their second
  one at essentially the same time, which produces a genuine circular-wait
  deadlock: A holds `Lock1` and waits for `Lock2` (held by B); B holds
  `Lock2` and waits for `Lock1` (held by A). Neither can ever proceed.
  `output_logs/rorder_bad.log` shows exactly this: both processes print
  their final "trying" line and then nothing more, ever -- confirmed by
  running it under an external timeout, which had to forcibly kill it.
* **`rorder_fixed`** (the fix): identical workload, except **both**
  processes now acquire the locks in the same fixed global order --
  `Lock1` before `Lock2` -- regardless of which one each process is
  logically "more interested in" first. `output_logs/rorder_fixed.log`
  shows both processes completing and printing "released both locks,
  done", with no hang.
* **Why consistent ordering eliminates the circular wait** (this
  explanation is also in the source comments of `rorder_fixed.c`): a
  circular wait requires each process in the cycle to hold one resource
  while waiting for another, in a pattern that closes into a loop. If
  every process is required to request resources in one single, fixed,
  total order, then whichever process reaches a given resource *first*
  is guaranteed to already hold everything earlier in the order that it
  needs -- it can never end up holding a *later* resource while blocked
  on an *earlier* one, because it always asks for the earlier one first.
  With two locks and a fixed order Lock1-then-Lock2 for everybody,
  whichever process wins the race for `Lock1` is guaranteed to go on to
  get `Lock2` as well; the other process simply blocks on `Lock1` until
  the first is completely done. There is no interleaving left in which
  each process ends up holding one lock while waiting on the other, so
  the circular-wait condition -- one of the four necessary conditions for
  deadlock -- can never be satisfied.

## Question 4: Combined Synchronization & Deadlock Avoidance (`user/syncdeadlock.c`)

5 processes, each needing 2 of 3 resource *pools* -- Printer (2 instances),
Scanner (1 instance), Disk (2 instances) -- implemented as three counting
semaphores sized to their pool capacities (again via the same `sem_alloc`/
`sem_wait`/`sem_signal` facility).

* **Strategy used: resource ordering, reused directly from Question 3.**
  The three resource types are given a fixed global order, Printer(0) <
  Scanner(1) < Disk(2), and every process -- no matter which two types it
  personally needs -- always requests the lower-ordered one first. This
  is the same argument as in Q3, generalized from 2 resources to 3: a
  single total order that every process obeys makes a circular wait
  impossible regardless of how many processes or resource types are
  involved, because no process can ever be caught holding a
  higher-ordered resource while blocked on a lower-ordered one.
* A shared page (`shm_get()`, reused from the previous assignment) holds a
  live in-use counter per resource type, updated under its own mutex
  semaphore and printed every time a resource is granted, so the reported
  counts can be checked directly against each pool's stated capacity to
  confirm no pool is ever over-subscribed.
* Each process prints when it requests a resource, when it is granted one
  (with the live in-use count), when it starts working, and when it
  releases both resources, across 4 cycles per process.

`output_logs/syncdeadlock.log` shows all 5 processes completing all 4
cycles each with no hang, and every printed in-use count staying at or
under its pool's capacity (Printer <= 2, Scanner <= 1, Disk <= 2) at every
point in the run.

---

## Summary of files added for Assignment 6

| File | Purpose |
|---|---|
| `user/bankers.c` | Q1: Banker's Algorithm (safety + resource-request algorithms) |
| `user/deadlockdetect.c` | Q2: wait-for graph construction + DFS cycle detection |
| `user/rorder_bad.c` | Q3: real 2-process deadlock via inconsistent lock ordering |
| `user/rorder_fixed.c` | Q3: same workload, fixed via consistent global lock ordering |
| `user/syncdeadlock.c` | Q4: 5-process, 3-resource-pool synchronization with resource-ordering deadlock avoidance |
| `Makefile` | Added the five programs above to `UPROGS` |

No kernel files were touched for this assignment -- `kernel/sem.c`,
`kernel/proc.c`'s shared-page support, and the `shm_get`/`sem_*` syscalls
already existed from the previous assignment and are used here unmodified.

Verified: builds with zero errors/warnings (`gcc -Wall -Werror`) using
`gcc-riscv64-linux-gnu`, and all five programs were actually run under
`qemu-system-riscv64` to produce the logs in `output_logs/`.
